/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package romanos;
import java.util.*;
/**
 *
 * @author zeidy
 */
public class NumerosRomanos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner sc=new Scanner(System.in);
       int N;
       int x=0;
       int y=0;
       int confirm;
        System.out.print("convertidor de numeros decimales a romanos");
        System.out.println("\n");
        do{
            x=0;
            try{
                System.out.print("introcuce el numero entero entre 1 y 3999: ");
                N=sc.nextInt();
                if(N < 1 || N > 3999){
                    System.out.print("Error.....por favor introdusca un numero dentro del rango indicado(1-3999)");
                    System.out.println("\n");
                    x=1;
                    
                }else{
                    System.out.println("El numero "+N+ " en numero romano es -> "+ convertirANumerosRomanos(N));
                    System.out.println("\n");
                       do{
                           y=0;
                           try{
                               System.out.print("Deseas introducir otro numero? "+ "\n");
                               System.out.print("1==si "+"\n");
                               System.out.print("2==no "+"\n");
                               confirm=sc.nextInt();
                                   if(confirm==1){
                                       x=1;
                                   }else if(confirm==2){
                                       System.out.println("\n");
                                       y=0;
                                   }else if((confirm>2)||(confirm<1)){
                                       System.out.println("\n");
                                       System.out.println("se ha introducido un valor fuera del rango");
                                       System.out.println("\n");
                                        y=1;
                                   
                                   }
                           }catch(InputMismatchException e){
                               System.out.print("Error...porfavor introduce un numero entero");
                               System.out.println("\n");
                               sc.next();
                               y=1;
                           }
                       }while(y==1);
                    }
            }catch(InputMismatchException e){
                System.out.print("Error...porfavor introduce un numero entero");
                System.out.println("\n");
                sc.next();
                x=1;       
            }
        }while(x==1);
    } 
    
    
public static String convertirANumerosRomanos(int numero){
    int i,miles,centenas,decenas,unidades;
    String romano = "";
    
    
    miles=numero/1000;
    centenas=numero/100 % 10;
    decenas=numero/10%10;
    unidades=numero % 10;
    
    
   //millar
   for(i=1; i<=miles;i++){
       romano=romano + "M";
       
   }
   
   //centenas
   if(centenas==9){
       romano=romano +"CM";
   }else if(centenas>=5){
       romano= romano +"D";
       for(i=6; i<= centenas;i++){
           romano= romano +"C";
       }
   }else if(centenas==4){
       romano=romano + "CD";
   }else{
       for(i=1;i<=centenas;i++){
           romano= romano +"C";
       }
   }
   
   //decenas
   
   if(decenas==9){
       romano= romano +"XC";
   }else if(decenas>=5){
       romano =romano + "L";
       for(i=6; i<=decenas; i++){
           romano= romano +"X";
       }
   }else if(decenas==4){
       romano=romano +"XL";
   }else{
       for(i=1;i<=decenas;i++){
           romano=romano +"X";
       }
   }
   
   //unidades
   if(unidades==9){
       romano= romano +"IX";
       
   }else if(unidades>=5){
       romano=romano +"V";
       for(i=6;i<= unidades; i++){
           romano= romano +"I";
       }
   }else if(unidades==4){
       romano=romano +"IV";
   }else{
       for(i=1;i<=unidades;i++){
           romano=romano +"I";
       }
   }
   return romano; 
}
   
}    
    
    
    
    

